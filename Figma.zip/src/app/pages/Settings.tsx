import {
  Box,
  Typography,
  Card,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Switch,
  Divider,
  useTheme,
} from '@mui/material';
import { DarkMode, LightMode, Notifications, Language } from '@mui/icons-material';
import { useState } from 'react';
import { useThemeMode } from '../context/ThemeContext';

export function Settings() {
  const theme = useTheme();
  const { darkMode, toggleDarkMode } = useThemeMode();
  const [notifications, setNotifications] = useState(true);

  const switchSx = {
    '& .MuiSwitch-switchBase.Mui-checked': { color: '#ff4e00' },
    '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': { bgcolor: '#ff4e00' },
  };

  return (
    <Box sx={{ minHeight: '100%', bgcolor: theme.palette.background.default }}>
      <Box sx={{ bgcolor: '#ff4e00', color: 'white', p: 3, pb: 4 }}>
        <Typography variant="h5">Configurações</Typography>
        <Typography variant="body2" sx={{ opacity: 0.85, mt: 0.5 }}>
          Personalize sua experiência
        </Typography>
      </Box>

      <Box sx={{ p: 2, mt: -2 }}>
        <Typography variant="overline" color="text.secondary" sx={{ pl: 1 }}>
          Aparência
        </Typography>
        <Card sx={{ mb: 3, mt: 1 }}>
          <List disablePadding>
            <ListItem>
              <ListItemIcon>
                {darkMode
                  ? <DarkMode sx={{ color: '#ff4e00' }} />
                  : <LightMode sx={{ color: '#ff4e00' }} />}
              </ListItemIcon>
              <ListItemText
                primary="Modo escuro"
                secondary={darkMode ? 'Ativado' : 'Desativado'}
              />
              <Switch checked={darkMode} onChange={toggleDarkMode} sx={switchSx} />
            </ListItem>
          </List>
        </Card>

        <Typography variant="overline" color="text.secondary" sx={{ pl: 1 }}>
          Notificações
        </Typography>
        <Card sx={{ mb: 3, mt: 1 }}>
          <List disablePadding>
            <ListItem>
              <ListItemIcon>
                <Notifications sx={{ color: '#ff4e00' }} />
              </ListItemIcon>
              <ListItemText
                primary="Alertas de eventos"
                secondary="Receber notificações de novos eventos"
              />
              <Switch
                checked={notifications}
                onChange={(e) => setNotifications(e.target.checked)}
                sx={switchSx}
              />
            </ListItem>
          </List>
        </Card>

        <Typography variant="overline" color="text.secondary" sx={{ pl: 1 }}>
          Geral
        </Typography>
        <Card sx={{ mt: 1 }}>
          <List disablePadding>
            <ListItem>
              <ListItemIcon><Language sx={{ color: '#ff4e00' }} /></ListItemIcon>
              <ListItemText primary="Idioma" secondary="Português (Brasil)" />
            </ListItem>
            <Divider />
            <ListItem>
              <ListItemText primary="Versão do app" secondary="1.0.0" />
            </ListItem>
          </List>
        </Card>
      </Box>
    </Box>
  );
}
